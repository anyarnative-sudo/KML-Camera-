KML Camera Android Project

ဒီဖိုင်က Android Studio project source ဖြစ်ပြီး APK မဟုတ်သေးပါ။

APK ဆောက်ရန်:
1. Android Studio ကို ကွန်ပျူတာမှာ install လုပ်ပါ။
2. KML_Android_Project folder ကို Android Studio မှ Open လုပ်ပါ။
3. Gradle sync ပြီး Android SDK Platform 35 ကို install လုပ်ပါ။
4. Build > Build Bundle(s) / APK(s) > Build APK(s) ကိုနှိပ်ပါ။
5. APK ကို app/build/outputs/apk/debug/app-debug.apk မှာရနိုင်ပါတယ်။

မှတ်ချက်:
- Camera permission ကို app ပထမဆုံးအသုံးပြုချိန်မှာ Allow ပေးပါ။
- Camera/zoom/flash စွမ်းဆောင်ရည်က ဖုန်း hardware နဲ့ Android WebView ပံ့ပိုးမှုအပေါ် မူတည်ပါတယ်။
- ဒီ project မှာ KML camera UI prototype ကို ထည့်ထားပါတယ်။ AI pose detection အစစ် မပါသေးပါ။
